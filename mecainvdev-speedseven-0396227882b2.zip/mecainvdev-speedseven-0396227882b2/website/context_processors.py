"""
Website context processors
"""

from django.conf import settings

def website_name(request):
    """website name shown in landing page"""
    return {'website_name': settings.WEBSITE_NAME}
