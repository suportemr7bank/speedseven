"""
Investiment application settings
"""

APPLICATION_MODEL_CLASS_ROOT_PATH = 'investment.installed_applications'