# Adding new host to inventory:

  1. Create a role folder in ansible/vars/ if it does not exist
    
  2. Copy file ansible/vars/server_vars.example.yaml folder into the role folder
    
  3. Edit this file and set variable values
    
  4. Rename file:
        Ex: server_vars.example.yaml => <server_name>.yaml
    
  5. Edit hosts.yaml (or create it) in ansible root to insert the new host

  ## Example (hosts.yaml):

    all:
    children:
      webservers:
        hosts:
          <server_name>:
            ansible_host: server_name.com  
              vars_files:
                - vars/roles/<server_name>.yaml
            
          <server_name2>:
            ...

          ...

        vars:
          ansible_ssh_user: root
          ssl_target_folder: /etc/ssl
