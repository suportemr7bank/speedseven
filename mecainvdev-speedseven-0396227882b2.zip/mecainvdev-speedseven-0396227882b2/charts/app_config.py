"""
Available implementation for javascript package
"""

from charts.charts.config import ChartsAvailable as _ChartsAvailable

# default js chart lib use do render html charts
CHARTS_DEFAULT_JS_LIB = _ChartsAvailable.APEXCHART
