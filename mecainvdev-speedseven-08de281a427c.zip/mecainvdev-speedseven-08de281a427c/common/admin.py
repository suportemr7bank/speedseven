"""
Admin models
"""

from django.contrib import admin

from .models import Bank, BankAccount


@admin.register(Bank)
class BanckAdmin(admin.ModelAdmin):
    """
    Admin model
    """

@admin.register(BankAccount)
class BanckAccountAdmin(admin.ModelAdmin):
    """
    Admin model
    """
