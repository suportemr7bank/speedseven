"""
Filter form mixin
"""

from django.db.models import Q

from . import filters


class FilterFormMixin:
    """
    Class to create filter form for listview
    """

    filter_form_class = None

    def get_context_data(self, **kwargs):
        """
        Insert filter form in the context
        """
        context = super().get_context_data(**kwargs)
        context['filter_form'] = self.filter_form
        return context

    def get_queryset(self):
        """
        Get queryset to apply filter
        """
        try:
            # pylint: disable=not-callable
            self.filter_form = self.filter_form_class(self.request.GET)
            queryset = super().get_queryset()
            if self.filter_form.is_valid():
                return self.apply_filter(queryset, self.filter_form)
            else:
                return queryset
        except AttributeError:
            return dict()

    # pylint: disable=unused-argument
    def apply_filter(self, queryset, filter_form):
        """
        Apply filter to queryset
        """
        return queryset


class NameEmailFilterMixin(FilterFormMixin):
    """
    Name and email fields filter
    """
    filter_form_class = filters.NameEmailFilterForm

    def apply_filter(self, queryset, filter_form):
        value = filter_form.cleaned_data.get('value')
        if value:
            field_name = filter_form.cleaned_data.get('field_name')
            if field_name == 'name':
                return self.name_query(queryset, value)
            elif field_name == 'email':
                return self.email_query(queryset, value)
        return queryset

    # pylint: disable=unused-argument
    def name_query(self, queryset, name):
        """
        Filter query by name
        Default imlementation does nothing
        """
        return queryset

    # pylint: disable=unused-argument
    def email_query(self, queryset, email):
        """
        Filter query by email
        Default imlementation does nothing
        """
        return queryset


class UserNameEmailFilterMixin(NameEmailFilterMixin):
    """
    Filter for User model
    """

    def name_query(self, queryset, name):
        name_list = name.split()
        query = Q()
        for word in name_list:
            query |= Q(first_name__icontains=word) | Q(
                last_name__icontains=word)
        return queryset.filter(query)

    def email_query(self, queryset, email):
        return queryset.filter(email__icontains=email)


class EmailFilterMixin(NameEmailFilterMixin):
    """
    Name and email fields filter
    """
    filter_form_class = filters.EmailFilterForm

    def apply_filter(self, queryset, filter_form):
        value = filter_form.cleaned_data.get('value')
        if value:
            field_name = filter_form.cleaned_data.get('field_name')
            if field_name == 'email':
                return self.email_query(queryset, value)
        return queryset

    # pylint: disable=unused-argument
    def email_query(self, queryset, email):
        """
        Filter query by email
        Default imlementation does nothing
        """
        return queryset


class InvitationEmailFilterMixin(EmailFilterMixin):
    """
    Filter for User model
    """

    def email_query(self, queryset, email):
        return queryset.filter(email__icontains=email)


class LoggedUserMixin:
    """
    Insert logged user in the from kwargs
    """

    def get_form_kwargs(self):
        """
        Insert logged user in the from kwargs
        """
        kwargs = super().get_form_kwargs()
        #pylint: disable=no-member
        kwargs['user'] = self.request.user
        return kwargs
