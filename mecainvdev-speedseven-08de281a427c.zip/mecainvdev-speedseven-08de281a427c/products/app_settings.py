"""
Products settings
"""

import pydoc
from django.conf import settings
from .agreement_render import DefaultAgreementRender

renderer = getattr(settings, 'PRODUCTS_AGREEMENT_RENDERER', None)
if renderer is None:
    AGREEMENT_RENDERER = DefaultAgreementRender
else:
    AGREEMENT_RENDERER = pydoc.locate(renderer)
