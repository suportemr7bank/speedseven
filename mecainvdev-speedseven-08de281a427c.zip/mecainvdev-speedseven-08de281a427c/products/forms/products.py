"""
    Forms customization
"""

import extra_views
from constance import config
from crispy_forms.helper import FormHelper
from crispy_forms.layout import HTML, Column, Layout, Row, Submit, Field
from django import forms
from django.db import transaction
from django.template import Context, Template
from django.template.exceptions import TemplateSyntaxError
from django.utils import timezone
from investment import models as invest_models

from .. import app_settings, models
from ..app_settings import AGREEMENT_RENDERER


class DefaultAgreementRender:
    """
    Agreement rendering according to a template
    """
    @staticmethod
    def render(user, agreement_template) -> str:
        """
        Render the client agreement according to agreement
        """
        data = {
            'name': user.get_full_name(),
            'email': user.email
        }

        template = Template(agreement_template.text)
        context = Context(data)

        return template.render(context)

    @staticmethod
    def available_tags():
        """
        Available tags
        """
        return ['{{nome}}', '{{email}}']


class AgreementForm(forms.ModelForm):
    """
    Create a client and inser the logged user
    """

    class Meta:
        """
        Meta class
        """
        model = models.AgreementTemplate
        fields = "__all__"
        widgets = {
            'instruction': forms.Textarea(attrs={'rows': 6}),
        }

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._set_layout()

    def clean(self):
        cleaned_data = super().clean()
        text = cleaned_data.get('text')
        try:
            AGREEMENT_RENDERER.render(
                user=None, agreement_text=text, preview=True)
        except TemplateSyntaxError as err:
            self.add_error(
                'text', f"Erro ao salvar texto do contrato. Mensagem original: {str(err)}")
        return cleaned_data

    def _set_layout(self):
        self.helper = FormHelper()
        self.helper.layout = Layout(
            Row(
                Column('name'),
                Column('product'),
                Column('display_text'),
            ),
            Row(
                Column('type'),
                Column('term_value'),
                Column('term_unit'),
            ),
            Row(
                Column(Field('text', rows=15)),
            ),
            Row(
                Column(self._instructions()),
            ),
        )

    def _instructions(self):
        tags = app_settings.AGREEMENT_RENDERER.available_tags()
        instructions = '<p class=""> Substitua as tags ' + \
            'abaixo no texto como são apresentadas <p>  ' + \
            '<p class=""> Exemplo: {% verbatim %} {{nome}} {% endverbatim %}' + \
            'será substituída pelo nome do usuário/cliente <p> ' + \
            '<p class=""> Tags: {% verbatim %} {{' + \
            f'{"}}, {{".join(tags)}' + '}}{% endverbatim %} </p> '
        text = HTML(instructions)
        return text


class PurchaseForm(forms.ModelForm):
    """
    Purchase form
    """

    accept_agreement = forms.BooleanField(
        label='Li e aceito os termos do contrato',
        initial=False,
        required=False,
        widget=forms.HiddenInput()
    )

    class Meta:
        """
        Meta class
        """
        model = models.ProductPurchase
        fields = ['product', 'alias', 'auto_renew', 'notify_before_end']

    def __init__(self, *args, **kwargs) -> None:
        products = kwargs.pop('products', None)
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        self.fields['product'].required = True
        self._load_products(products)

        self.fields['alias'].widget.attrs['placeholder'] = self.fields['alias'].label + \
            " (opcional)"
        self.fields['alias'].label = ""

        if days := getattr(config, 'AGREEMENT_NOTIFY_END_BEFORE_DAYS', 15):
            self.fields[
                'notify_before_end'].label = f"Notificar término do contrato {days} antes do vencimento"

        self._set_layout()

    def _load_products(self, products):
        if products:
            self.fields['product'].choices = list(products.values_list('id', 'display_text')
                                                  )
        else:
            product = models.Product
            # pylint: disable=no-member
            choices = product.objects.none()
            self.fields['product'].choices = choices

    def _set_layout(self):
        self.helper = FormHelper()
        # Id use by js script
        self.helper.form_tag = None
        self.helper.layout = Layout(
            'product',
            'alias',
            'auto_renew',
            'notify_before_end',
            'accept_agreement',
            Row(
                # This button fires an agreement modal. Don't change button id
                Column(
                    Submit(name='purchase_product', value='Contratar', css_id='id_purchase_product', css_class='w-100 btn-success'),
                    css_class='col-12'
                )
            )
        )

    def clean(self):
        cleaned_data = super().clean()
        product = cleaned_data.get('product')
        if product:
            # Only users with investor profile can purchase a product
            investor_profile = getattr(self.user, 'investorprofile', None)
            if not investor_profile:
                self.add_error(
                    None, 'Seu perfil de investidor não está definido. Entre em contato conosco')
                return cleaned_data

            # Investor profile must mach one of the product profiles
            if not product.profileproduct_set.filter(profile=investor_profile.profile).exists():
                self.add_error(
                    None, f'Você não tem acesso a este produto ({product.display_text})')
                return cleaned_data

            # Product is available only if it has anassociated agreement
            agreement_template = product.agreementtemplate_set.last()
            if not agreement_template or not investor_profile:
                self.add_error(None, 'Produto indisponível no momento.')
                return cleaned_data

        else:
            self.add_error('product', 'Este campo é obrigatório')

        return cleaned_data

    def save(self, commit=True):
        cleaned_data = self.cleaned_data
        product = cleaned_data['product']

        agreement_template = product.agreementtemplate_set.filter(
            type=self.user.client.type).last()

        term = agreement_template.term

        date_created = timezone.localtime(timezone.now())

        obj = super().save(commit=False)
        obj.user = self.user
        obj.agreement_template = agreement_template
        obj.agreement = app_settings.AGREEMENT_RENDERER.render(
            self.user, agreement_template.text)
        obj.date_purcahsed = date_created
        obj.date_expire = date_created + term if term else None
        if commit:
            with transaction.atomic():
                obj.save()
                self.create_application_account(obj)
        return obj

    def create_application_account(self, product_purchase):
        """
        Creates an application account according to the product
        """
        # pylint: disable=no-member
        app_acc = invest_models.ApplicationAccount.objects.create(
            application=product_purchase.product.application,
            user=self.user,
            operator=self.user
        )
        app_acc.post_create()
        product_purchase.application_account = app_acc
        product_purchase.save()


class ProfileProductItem(extra_views.InlineFormSetFactory):
    """
    Inline formset for profile product registering
    """
    model = models.ProfileProduct
    fields = "__all__"


class DashboardProductItem(extra_views.InlineFormSetFactory):
    """
    Inline formset for profile product registering
    """
    model = models.ProductDashboard
    fields = "__all__"


class ProductForm(forms.ModelForm):
    """
    Purchase form
    """

    is_active = forms.BooleanField(label="Ativo", required=False)

    class Meta:
        """
        Meta class
        """
        model = models.Product
        fields = '__all__'

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        choices = invest_models.Application.objects.filter(
            product__isnull=True, is_active=True).values_list('pk', 'display_text')

        if choices:
            self.fields['application'].choices = choices
        else:
            self.fields['application'].choices = [('', 'Nenhuma aplicação disponível')]
            self.fields['application'].disabled = True

        if self.instance.pk:
            self.fields['application'].disabled = True
            self.initial['is_active'] = self.instance.application.is_active

    def save(self, commit=True):
        obj = super().save(commit=False)
        if getattr(obj, 'application', None):
            application = obj.application
            application.is_active = self.cleaned_data['is_active']
            if commit:
                application.save()
        if commit:
            obj.save()
        return obj
