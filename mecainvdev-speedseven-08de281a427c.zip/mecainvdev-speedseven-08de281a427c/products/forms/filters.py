"""
    Forms to filter list/table rows
"""

from crispy_forms.bootstrap import FormActions, PrependedText
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Column, Layout, Submit
from django import forms

from common.forms import fields
from investment import models as invest_models

from ..models import Product


class OperationsFilterForm(forms.Form):
    """
    Form to filter client operations in report
    """

    product = forms.ChoiceField(
        label='', choices=[('0', 'Aplicação')], required=False)
    operation = forms.ChoiceField(
        label='', choices=[('MOV', 'Movimentação')], required=False)

    init_date = forms.DateField(
        label='',
        required=False,
        widget=fields.DatePickerInput(options={'dateFormat': 'd/m/Y'}),
    )

    final_date = forms.DateField(
        label='',
        required=False,
        widget=fields.DatePickerInput(options={'dateFormat': 'd/m/Y'}),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['product'].choices += Product.objects.filter(
            application__is_active=True).values_list('pk', 'display_text')
        self.fields['operation'].choices += invest_models.ApplicationOp.OperationType.choices

        self.helper = FormHelper()
        self.helper.form_method = 'get'
        self.helper.form_class = 'row'
        self.helper.layout = Layout(
            Column('product', css_class='col-12 col-md-auto'),
            Column('operation', css_class='col-12 col-md-auto'),
            Column(PrependedText('init_date', 'Início'),
                   css_class='col-12 col-md-auto'),
            Column(PrependedText('final_date', 'Fim'),
                   css_class='col-12 col-md-auto'),
            Column(FormActions(Submit('', 'Filtrar', css_class='col-12 btn-success')),
                   css_class='col-12 col-md-auto')
        )
