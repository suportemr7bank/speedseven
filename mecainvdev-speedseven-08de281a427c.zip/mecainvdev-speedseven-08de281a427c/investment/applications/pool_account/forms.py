"""
Application forms
"""

from datetime import timedelta

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Column, Layout, Row
from django import forms
from django.utils import timezone

from investment.interfaces.forms import (MoneyTransfer, MoneyTransferFormBase,
                                         OperationFormBase, ApplicationSettingsFormMixin)
from investment.operations.operations import ApplicationAccountOperation

from .models import AccountSettings, ApplicationSettings


class ApplicationSettingsForm(ApplicationSettingsFormMixin, forms.ModelForm):
    """ Application settings"""

    class Meta:
        """
        Meta class
        """
        model = ApplicationSettings
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._set_laytout()

    def _set_laytout(self):
        self.helper = FormHelper()
        self.helper.layout = Layout(
            Row(
                Column('target_client'),
                Column(''),
                css_class='pb-4'
            ),
            Row(
                Column('min_initial_deposit'),
                Column('min_deposit'),
            ),
            Row(
                Column('deposit_term'),
                Column(''),
            ),
            Row(
                Column('withdraw_account_term'),
                Column('withdraw_income_term')
            ),
            Row(
                Column('withdraw_threshold_term'),
                Column('value_threshold'),
                css_class='pb-4'
            ),
            Row(
                Column('ranges'),
                Column(''),
            ),

        )


class AccountSettingsForm(forms.ModelForm):
    """ Application account settings"""

    class Meta:
        """
        Meta class
        """
        model = AccountSettings
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        self.application_account = kwargs.pop('user')
        self.application_account = kwargs.pop('application_account')
        super().__init__(*args, **kwargs)
        if acc_settings := getattr(self.application_account, 'accountsettings', None):
            self.initial = acc_settings.__dict__
            self.instance = acc_settings

    def save(self, commit=True):
        obj = super().save(commit=False)
        obj.application_account = self.application_account
        if commit:
            obj.save()
        return obj


class ManualTranferFormBase(MoneyTransferFormBase):
    """ Manual money transfer form

    1. Handles deposit and witdraw request

    When the user (non admin) requests an operation it is stored in MoneyTranfer model in
    wating state and sent to an admin user to approval.
    Admin user can request an operation on behalf of an user and can aprove the request
    when saving or send to approval also.

    2. Handles request approval

    Deposit opertaion:

    When an admin user approves the request, a deposit is made immediately or scheduled
    to be done in the future by an operation routine in background. The application
    settings are checked for the parameter deposti_term which determines the operation completion.
    The deposit_term is checked first in the user applicatin account setting an then in the
    application settings if the former does not exist.

    Withdraw operation:

    When the request is approved an withdraw is made immediately.
    """

    operation_class = ApplicationAccountOperation
    processing = MoneyTransfer.Processing.MANUAL

    approve = forms.ChoiceField(label='Aprovação',
                                choices=(
                                    ('', '-----'),
                                    ('approved', 'Marcar como aprovado ao salvar'),
                                    ('delegate', 'Enviar para aprovação')
                                ),
                                required=True
                                )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.operation = self.operation_class()

        if not self.user.is_superuser:
            self.fields.pop('approve')

    def save(self, commit=True):
        obj = super().save(commit=False)
        if commit:
            # Just stores the request for future approval (admin)
            obj.save()
            # Approve or allow updating fields (ex: receitp_file) if already approved
            if self.user.is_superuser:
                if self.cleaned_data['approve'] == 'approved':
                    if self._approve_request(obj):
                        self._exec_operation(obj)
                        obj.save()
                else:
                    self.reprove_request(obj)
                    obj.save()
        return obj

    def _approve_request(self, obj):
        if obj.state == MoneyTransfer.State.WAITING:
            date_finished = timezone.localtime(timezone.now())
            obj.date_finished = date_finished
            obj.state = MoneyTransfer.State.FINISHED
            obj.processor = self.user
            obj.last_trial_date = date_finished
            obj.trial = 1
            return True
        return False

    def reprove_request(self, obj):
        """
        Implement reproval request here
        This class only set aproved or send for approval (no modification needed)
        """

    def _exec_operation(self, money_tranfer):
        withdraw_ops = [
            MoneyTransfer.Operation.WITHDRAW_WALLET,
            MoneyTransfer.Operation.WITHDRAW_INCOME
        ]

        if self.transfer_operation == MoneyTransfer.Operation.DEPOSIT:
            if term := self._eval_deposit_term(money_tranfer):
                self._schedule_deposit(money_tranfer, term)
            else:
                self._make_deposit(money_tranfer)

        elif self.transfer_operation in withdraw_ops:
            self._make_withdraw(money_tranfer)

    def _eval_deposit_term(self, money_tranfer):
        acc = money_tranfer.application_account
        if account_deposit_term := acc.accountsettings.deposit_term:
            term = account_deposit_term
        elif application_deposit_term := acc.application.settings.deposit_term:
            term = application_deposit_term
        else:
            term = None
        return term

    def _make_deposit(self, money_transfer):
        app_op = self.operation.make_deposit(
            operator=self.user,
            application_account=self.application_account,
            value=money_transfer.value,
            description=money_transfer.display_message,
            operation_date=None,
        )
        money_transfer.application_operation = app_op

    def _schedule_deposit(self, money_tranfer, term):
        operation_date = timezone.localtime(
            timezone.now() + timedelta(days=term))
        self.operation.schedule_deposit(
            money_tranfer, operation_date, operator=self.user)

    def _make_withdraw(self, money_transfer):
        app_op = self.operation.make_withdraw(
            operator=self.user,
            application_account=self.application_account,
            value=money_transfer.value,
            operation_type=self.cleaned_data['operation'],
            description=money_transfer.display_message,
            operation_date=None
        )
        money_transfer.application_operation = app_op


class ManualDepositForm(ManualTranferFormBase):
    """
    Manual deposit form
    """
    transfer_operation = MoneyTransfer.Operation.DEPOSIT

    def clean(self):
        cleaned_data = super().clean()
        acc = self.application_account

        # First deposit rule
        if value := cleaned_data.get('value', None):
            if not acc.applicationop_set.exists():
                if acc_min := acc.accountsettings.min_initial_deposit:
                    if value < acc_min:
                        self.add_error(
                            'value', f'O depósito inicial deve ser maior ou igual a {acc_min}')
                elif app_min := acc.application.settings.min_initial_deposit:
                    if value < app_min:
                        self.add_error(
                            'value', f'O depósito inicial deve ser maior ou igual a {app_min}')
            else:
                app_min = acc.application.settings.min_deposit
                if value < app_min:
                    self.add_error(
                        'value', f'Depósito mínimo permitido maior ou igual a {app_min}')

        return cleaned_data


class ManualWithdrawForm(ManualTranferFormBase):
    """
    Manual withdraw form
    """
    transfer_operation = MoneyTransfer.Operation.WITHDRAW_WALLET

    class Meta(ManualTranferFormBase.Meta):
        """
        Meta class
        """
        model = MoneyTransfer
        fields = ['operation', 'value', 'receipt_file', 'display_message']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        wit_wal = MoneyTransfer.Operation.WITHDRAW_WALLET.value
        wit_inc = MoneyTransfer.Operation.WITHDRAW_INCOME.value
        choices = [choice for choice in MoneyTransfer.Operation.choices if choice[0] in [
            wit_wal, wit_inc]]
        self.fields['operation'].choices = choices

        self.fields['receipt_file'].required = False

        if not self.user.is_superuser:
            self.fields.pop('receipt_file')

    def clean(self):
        cleaned_data = super().clean()
        approval = self.cleaned_data.get('approve')
        if approval == 'approved':
            if not cleaned_data.get('receipt_file', None):
                self.add_error(
                    'receipt_file', 'Aprovação direta requer comprovante')
        return cleaned_data


class OperationApprovalForm(ManualTranferFormBase):
    """
    Manual operation approval (deposit/withdraw) form
    """
    processing = MoneyTransfer.Processing.MANUAL

    # Initially set to deposit but change according to MoneyTransfer object
    transfer_operation = MoneyTransfer.Operation.DEPOSIT

    class Meta(OperationFormBase.Meta):
        """
        Meta class
        """
        model = MoneyTransfer
        fields = ['operation', 'value', 'receipt_file',
                  'display_message', 'error_message']

    approve = forms.ChoiceField(label='Aprovação',
                                required=True,
                                choices=(
                                    ('', '-----'),
                                    ('approved', 'Aprovado'),
                                    ('disapproved', 'Reprovado'))
                                )

    field_order = ['operation', 'value', 'receipt_file',
                   'display_message', 'approve', 'error_message']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['operation'].disabled = True
        self.fields['value'].disabled = True
        self.fields['display_message'].disabled = True
        self.fields['error_message'].help_text = 'Preencha somente em caso de reprovação'
        self.fields['receipt_file'].required = False

        if self.instance.pk:
            self.transfer_operation = self.instance.operation

            disable_receipt = self.instance.operation == MoneyTransfer.Operation.DEPOSIT
            self.fields['receipt_file'].disabled = disable_receipt

            disable_approval = self.instance.state != MoneyTransfer.State.WAITING
            self.fields['approve'].disabled = disable_approval

            if self.instance.state == MoneyTransfer.State.FINISHED:
                self.initial['approve'] = 'approved'
                self.fields['error_message'].disabled = True
            elif self.instance.state == MoneyTransfer.State.ERROR:
                self.initial['approve'] = 'disapproved'
                self.fields['receipt_file'].disabled = True

    def clean(self):
        cleaned_data = super().clean()
        approval = self.cleaned_data.get('approve', None)
        if approval == 'approved' and not cleaned_data.get('receipt_file', None):
            self.add_error('receipt_file', 'Aprovação requer comprovante')
        return cleaned_data

    def reprove_request(self, obj):
        if obj.state == MoneyTransfer.State.WAITING:
            date_finished = timezone.localtime(timezone.now())
            obj.date_finished = date_finished
            obj.state = MoneyTransfer.State.ERROR
            obj.processor = self.user
            obj.last_trial_date = date_finished
            obj.trial = 1
