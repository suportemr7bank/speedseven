"""
    Forms customization
"""
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Column, Layout, Row, Field
from django import forms

from .. import models


class UserForm(forms.ModelForm):
    """
        Change User form requirements
    """
    class Meta:
        """
            Meta configuration
        """
        model = models.User
        fields = ['first_name', 'last_name', 'email', 'is_active']

    def __init__(self, *args, **kwargs) -> None:
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        self.fields['first_name'].required = True
        self.fields['last_name'].required = True
        self.fields['email'].required = True
        if self.instance.pk:
            if self.instance.pk == self.user.pk:
                self.fields.pop('is_active')

    def clean(self):
        """
            Prevent duplicated email
        """
        cleaned_data = super().clean()
        email = cleaned_data.get('email')
        if 'email' in self.changed_data:
            if models.User.objects.filter(email__iexact=email).exists():
                self.add_error('email', "Um usuário com este email já existe")
        return cleaned_data

    def save(self, commit=True):
        """
            Save email in the username field
        """
        user = super().save(commit=False)
        user.username = self.cleaned_data['email']
        if commit:
            user.save()
        return user


class AdminForm(UserForm):
    """
    Set user as admin
    """

    def save(self, commit=True):
        """
        Set user as admin
        """
        user = super().save(commit=False)
        user.is_superuser = True
        user.is_staff = True
        if commit:
            user.save()
        return user


class AccepanceTermForm(forms.ModelForm):
    """
    Acceptance termo form
    """

    class Meta:
        """
        Meta class
        """
        model = models.AcceptanceTerm
        fields = ['title', 'type', 'version',
                  'is_active', 'annotation', 'text']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()

        self.helper.layout = Layout(
            Row(
                Column(
                    Row('title'),
                    Row(Column('type'), Column('version'), Column(
                        'is_active', css_class='mt-4 pt-3'))
                ),
                Column(Field('annotation', rows=5))
            ),
            Row(Column(Field('text', rows=20))),
        )
