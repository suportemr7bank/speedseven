"""
Core backgroud tasks
"""


import channels.layers
from asgiref.sync import async_to_sync
from celery import shared_task
from celery.utils.log import get_task_logger

from . import email

logger = get_task_logger(__name__)


channel_layer = channels.layers.get_channel_layer()

def _notify_channel(email_batch):
    batch_id = email_batch.id
    date = email_batch.date_finished
    data = {
        'sent': {
            'id': f'id_{batch_id}_sent',
            'value': email_batch.sent
        },
        'status': {
            'id': f'id_{batch_id}_status',
            'value': email_batch.status,
            'text': email_batch.get_status_display(),
        },
        'date_finished': {
            'id': f'id_{batch_id}_date_finished',
            'value': date.strftime('%d/%m/%Y %H:%M:%S') if date else None
        },
    }
    message = {
        'type': 'send_batch_email',
        'data': data
    }
    async_to_sync(channel_layer.group_send)('batch_email', message)


@shared_task
def send_email(email_batch_message_pk):
    """
    Sent batch email in background
    """

    batch_mail = email.BatchEmail(
        email_batch_message_pk,
        _notify_channel)

    batch_mail.send()
