Initial requirements

1. /webapps folder with user (speedseven) and usergroup (webapps)

2. A git repository access key generated in the folder:
    
    /webapps/.ssl/<sshkey>

3. Access key installed in the git repository   
