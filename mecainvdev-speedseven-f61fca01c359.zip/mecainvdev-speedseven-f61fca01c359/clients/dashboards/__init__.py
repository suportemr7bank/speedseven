"""
Available dashboar classes
"""

from .products import (LowRiskProductDashboard,
                       MediumRiskProductDashboard, HighRiskProductDashboard)
