"""
Charts setup
"""


class ChartsAvailable:
    """
    Charts available js implementation
    """

    APEXCHART = 'apexchart'
