"""
Core forms
"""

from django import forms
from common import models

class BanckAccountForm(forms.ModelForm):
    """
    Create a client banck account and insert logged user
    """

    class Meta:
        """
        Meta class
        """
        model = models.BankAccount
        exclude = ['user']

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user')
        super().__init__(*args, **kwargs)
        self.fields['bank'].required = True
        self.fields['bank_branch_number'].required = True
        self.fields['account_number'].required = True

    def save(self, commit=True):
        """
        Insert logged user to bank account
        """
        bankaccount = super().save(commit=False)
        if commit:
            if not getattr(bankaccount,'user', None):
                bankaccount.user = self.user
            bankaccount.save()
        return bankaccount
