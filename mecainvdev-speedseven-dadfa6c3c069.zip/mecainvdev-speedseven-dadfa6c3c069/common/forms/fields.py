"""
Customize django flatpicker
"""

from django import forms
from flatpickr import DatePickerInput as _DatePickerInput
from flatpickr import DateTimePickerInput as _DateTimePickerInput


class DatePickerInput(_DatePickerInput):
    """
    Prevend default cript loading in form rendering
    The scrips are loaded in main.js
    """

    @property
    def media(self):
        """
        Prevent media render
        """
        return forms.Media()


class DateTimePickerInput(_DateTimePickerInput):
    """
    Prevend default cript loading in form rendering
    The scrips are loaded in main.js
    """

    @property
    def media(self):
        """
        Prevent media render
        """
        return forms.Media()
