Set playbooks variables:

    1. Create a role folder in this folder if it does not exist
    2. Copy files in example folder to role folder
    3. Edit these files and set variable values
    4. Rename files removing the "example" string in the file name:
        Ex: server_vars.example.yaml => server_vars.yaml