"""
Generic elements which not belong to any lib or not is a plot

"""

from dataclasses import dataclass

from charts.charts.base import AbstractChart, ChartDataType


@dataclass
class Card(AbstractChart):
    """
    Card element. Only title and text (not a plot)
    """

    text: str = ""
    chart_type = ChartDataType.CARD

    def get_json_data(self):
        """
        Json data to javascript chart library
        """

        return f'''
            <div class="card bg-black">
                <div class="h2  " >{self.title} {self.text}</div>
            </div>
            '''