"""
Admin models
"""

from django.contrib import admin

from .models import Application, ApplicationAccount, ApplicationOp, MoneyTransfer


@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    """
    Application model admin
    """


@admin.register(ApplicationAccount)
class ApplicationAccountAdmin(admin.ModelAdmin):
    """
    Application account model admin
    """


@admin.register(ApplicationOp)
class ApplicationOpAdmin(admin.ModelAdmin):
    """
    Application account operation model admin
    """


@admin.register(MoneyTransfer)
class MoneyTransferAdmin(admin.ModelAdmin):
    """
    Money transfer model admin
    """
