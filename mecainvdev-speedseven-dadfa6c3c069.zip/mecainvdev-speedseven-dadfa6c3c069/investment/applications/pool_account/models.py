"""
Application models
"""


from django.db import models
from django.core.validators import MinValueValidator
from investment.models import Application, ApplicationAccount
from investment.interfaces.validators import (
    validate_null_or_greate_than_zero, validate_greate_than_zero)
from investment.interfaces.base import ApplicationSettingBaseModel


class ApplicationSettings(ApplicationSettingBaseModel):
    """
    Application model settings
    """

    class Meta:
        """
        Meta class
        """
        verbose_name = 'Configuração da aplicação'
        verbose_name_plural = 'Configurações das aplicações'

    application = models.OneToOneField(
        Application, verbose_name='Aplicação',
        related_name='pool_account_settings', on_delete=models.CASCADE, editable=False)

    min_initial_deposit = models.FloatField(
        verbose_name='Depósito inicial mínimo',
        help_text='Valor inicial aceito para abertura de conta',
        validators=[validate_greate_than_zero]
    )

    min_deposit = models.FloatField(
        verbose_name='Depósito mínimo',
        help_text='Valor mínimo para depósito após abertura de conta',
        validators=[validate_greate_than_zero]
    )

    deposit_term = models.IntegerField(
        verbose_name='Prazo para aporte (dias)',
        help_text='Prazo para o aporte ser compensado',
        validators=[MinValueValidator]
    )

    ranges = models.CharField(max_length=512,
                              verbose_name='Faixas rendimento',
                              help_text="Ex: 0,00; 100.000,00; 500.000,00",
                              null=True, blank=True
                              )

    withdraw_account_term = models.IntegerField(
        verbose_name='Prazo para resgate da carteira (dias)',
        validators=[MinValueValidator]
    )

    withdraw_income_term = models.IntegerField(
        verbose_name='Prazo para resgate do rendimento (dias)',
        validators=[MinValueValidator]
    )

    value_threshold = models.FloatField(
        verbose_name='Valor limite',
        help_text='Contas com valor acima deste tem prazo de resgate especial',
        validators=[MinValueValidator]
    )

    withdraw_threshold_term = models.IntegerField(
        verbose_name='Prazo para resgate acima do valor limite (dias)',
        help_text='Todo resgate acima do valor limite obedecerá este prazo',
        validators=[MinValueValidator]
    )


class AccountSettings(models.Model):
    """ Application model settings"""

    class Meta:
        """
        Meta class
        """
        verbose_name = 'Configuração da conta do cliente'
        verbose_name_plural = 'Configurações das contas dos clientes'

    application_account = models.OneToOneField(
        ApplicationAccount, verbose_name='Aplicação', on_delete=models.CASCADE, editable=False)

    custom_rate = models.FloatField(
        verbose_name='Percentual especial',
        help_text='Sobrepõe o valor de aporte padrão da aplicação somente para este cliente',
        null=True, blank=True,
        validators=[validate_null_or_greate_than_zero]
    )

    min_initial_deposit = models.FloatField(
        verbose_name='Depósito mínimo inicial',
        help_text='Depósito mínimo específico para o cliente',
        null=True, blank=True,
        validators=[validate_null_or_greate_than_zero]
    )

    deposit_term = models.IntegerField(
        verbose_name='Prazo para aporte em dias',
        help_text='Prazo de compensação de aporte específico para o cliente',
        null=True, blank=True,
        validators=[MinValueValidator]
    )
