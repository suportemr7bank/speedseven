from django.apps import AppConfig


class NinjatraderAccountConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'investment.applications.ninjatrader_account'
