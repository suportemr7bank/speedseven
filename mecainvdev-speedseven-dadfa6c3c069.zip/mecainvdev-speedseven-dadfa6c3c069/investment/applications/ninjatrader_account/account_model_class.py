"""
Application definitions
"""

from investment.interfaces.base import ApplicationModelClassBase, PostCreateState

from . import models

class NinjaTradertPoolAccount(ApplicationModelClassBase):
    """
    Class with application definitons
    """
    settings_related_name = 'ninja_trader_settings'
    # application_settings_form = forms.ApplicationSettingsForm

    @classmethod
    def aplication_post_create(cls, application):
        super().aplication_post_create(application)
        # pylint: disable=no-member
        models.ApplicationSettings.objects.create(
            application=application,
        )

    @classmethod
    def aplication_account_post_create(cls, application_account) -> PostCreateState:
        return PostCreateState.CREATED
