"""
Application forms interfaces

"""

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, HTML
from django import forms

from ..operations.operations import ApplicationAccountOperation
from ..models import MoneyTransfer



class OperationFormBase(forms.ModelForm):
    """
    Base form for money operations
    Ex: deposit, withdraw, deposti/withdraw approval, etc
    """

    processing: MoneyTransfer.Processing = None
    max_trials = 1

    class Meta:
        """
        Meta class
        """
        model = MoneyTransfer
        fields = ['value', 'receipt_file', 'display_message']

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        self.application_account = kwargs.pop('application_account')
        super().__init__(*args, **kwargs)
        self.set_layout()
        if self.processing is None:
            raise Exception(
                f'Transfer form improperly configured {self.__class__}')

    def set_layout(self):
        """
        Set the form fields layout
        """
        self.helper = FormHelper()
        fields = [
            HTML(f'<p>{self.application_account.user.get_full_name()}</p>'),
            HTML(
                f'<p class="pb-4"> <strong>Saldo da aplicação:</strong> R${self.application_account.balance}</p>'),
        ]
        fields = fields + [key for key, value in self.fields.items()]
        self.helper.layout = Layout(*fields)

    def save(self, commit=True):
        """
        Save tranfer request
        """
        obj = super().save(commit=False)
        obj.application_account = self.application_account
        obj.processing = self.processing
        obj.max_trials = self.max_trials
        if not getattr(obj, 'operator', None):
            obj.operator = self.user

        if commit:
            obj.save()

        return obj


class MoneyTransferFormBase(OperationFormBase):
    """
    Base form for money tranfer operations
    """

    transfer_operation: MoneyTransfer.Operation = None
    max_trials = 1

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.transfer_operation is None:
            raise Exception(
                f'Transfer form unproperly configured {self.__class__}')
        self.fields['receipt_file'].required = True

    def clean(self):
        cleaned_data = super().clean()

        if value := cleaned_data.get('value'):
            app_acc_op = ApplicationAccountOperation()
            if self.transfer_operation == MoneyTransfer.Operation.DEPOSIT:
                app_acc_op.validate_deposit(self.application_account, value, operation_date=None)
            elif self.transfer_operation == MoneyTransfer.Operation.WITHDRAW_WALLET:
                app_acc_op.validate_withdraw(self.application_account, value, operation_date=None)

        return cleaned_data

    def save(self, commit=True):
        """
        Save tranfer request
        """
        obj = super().save(commit=False)
        obj.operation = self.transfer_operation
        if commit:
            obj.save()
        return obj


class ApplicationSettingsFormMixin():
    """ Application settings mixin"""

    def __init__(self, *args, **kwargs):
        self.application = kwargs.pop('user')
        self.application = kwargs.pop('application')
        super().__init__(*args, **kwargs)
        if app_settings := self.application.settings:
            self.initial = app_settings.__dict__
            self.instance = app_settings

    def clean(self):
        """
        Verify settings_related_name to access related model ApplicationSettings
        from application implementation.
        """
        cleaned_data = super().clean()
        if not self.application.settings_related_name:
            self.add_error('', 'Aplicação não consegue acessar configurações do modelo relacionado')
        return cleaned_data

    def save(self, commit=True):
        """
        Save application
        """
        obj = super().save(commit=False)
        obj.application = self.application
        if commit:
            obj.save()
        return obj
