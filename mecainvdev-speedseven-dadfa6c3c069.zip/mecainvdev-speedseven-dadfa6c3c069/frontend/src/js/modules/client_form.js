const initClientForm = () =>  {

    let radio_pf = document.querySelector('#id_type_0')
    let radio_pj = document.querySelector('#id_type_1')

    if (radio_pf && radio_pf){
        let companyAgreement = document.querySelector('#id_company_agreement')
        let companyName = document.querySelector('#id_company_name')
        let cnpj = document.querySelector('#id_cnpj')

        radio_pf.addEventListener('change', (event) => {
            companyAgreement.disabled = true
            companyName.disabled = true
            cnpj.disabled = true
            companyAgreement.value = ''
            companyName.value = ''
            cnpj.value = ''
        })
        radio_pj.addEventListener('change', (event) => {
            companyAgreement.disabled = false
            companyName.disabled = false
            cnpj.disabled = false
        })
    }
}

export {initClientForm}