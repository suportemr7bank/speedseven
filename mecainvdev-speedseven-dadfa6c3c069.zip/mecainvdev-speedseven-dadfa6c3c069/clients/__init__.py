default_app_config = 'clients.apps.ClientsConfig'
