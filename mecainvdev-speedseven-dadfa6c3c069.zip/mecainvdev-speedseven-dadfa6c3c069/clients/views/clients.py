"""
    Client views
"""


from django.db.models import F, Max, Q, Subquery, OuterRef
from django.http import Http404
from django.shortcuts import redirect
from django.urls import reverse, reverse_lazy
from django.views.generic import TemplateView
from django_tables2 import SingleTableMixin
from constance import config

from accounts.auth import mixins as auth_mixins
from accounts import views as accounts_views
from accounts import roles as accounts_roles
from clients.views.mixins import CompleteSignUpMixin, ClientRoleMixin
from common.messages import message_modal_add
from common.views import core, generic, mixins
from core import models as core_models
from investorprofile import views as invprof_view
from products import models as products_models, dashboards as core_dashboard
from products.forms import mixins as products_forms_mixins, products as products_forms
from investment.views import application as invest_views
from investment.interfaces.base import TargetClient
from investment import models as invest_models

from .. import forms, models, tables


class StartView(CompleteSignUpMixin,
                mixins.TitleMixin,
                TemplateView):
    """
        Client start view
    """
    title = "Cadastro"
    header_message = 'Complete os seguinte passos para continuar'
    skip_signup_test = True

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.is_signup_completed:
            products_purchased, products_ids = self.get_products()
            if products_purchased:
                context['products'] = products_purchased
                purchase_id = self.request.GET.get(
                    'purchase_id', products_purchased[0]['purchase_id'])
                context['selected_product'] = purchase_id

            if products_ids:
                widgets = []
                # pylint: disable=no-member
                query = invest_models.ApplicationAccount.objects.filter(
                    user=self.request.user, is_active=True,
                    creation_status=invest_models.ApplicationAccount.CreationStatus.CREATED)

                for app_acc in query:
                    application = app_acc.application
                    template = application.application_class.get_widget_template(
                        application)
                    if template:
                        widgets.append(
                            {
                                'name': app_acc.application.product.display_text,
                                'template': template
                            }
                        )

                context['widgets'] = widgets
                # template = self._get_dashboard_template(
                #     products[0]['product_id'])
                # context['product_template'] = template
        return context

    # def _get_dashboard_template(self, product_id):
    #     # pylint: disable=no-member
    #     try:
    #         template = products_models.ProductDashboard.objects.get(
    #             product__pk=product_id).dashboard.get_class().template_name
    #         return template
    #     except products_models.ProductDashboard.DoesNotExist:
    #         return None

    def get_products(self):
        """
        Return the user products
        """
        # pylint: disable=no-member
        user_products = products_models.ProductPurchase.objects.filter(
            Q(date_expire__isnull=True) | Q(date_cancelled__isnull=True),
            user=self.request.user
        )

        products_ids = user_products.values('product__id').annotate(
            id=F('product__id')).values_list('id', flat=True).distinct()

        products_purchased = user_products.annotate(
            name=F('product__display_text'),
            purchase_id=F('pk'),
        ).values('name', 'alias', 'purchase_id', 'product_id',
                 'application_account_id').order_by('purchase_id')

        return products_purchased, products_ids

    def get_template_names(self):
        if self.is_signup_completed:
            return ['clients/start/start.html']
        else:
            return ['clients/complete_signup.html']


class ClientUpdateView(CompleteSignUpMixin,
                       generic.UpdateView):
    """
        Update client
        Client is creates by signal when user signed up
    """
    model = models.Client
    form_class = forms.ClientForm
    template_name = 'common/form.html'
    title = 'Dados pessoais'
    success_url = reverse_lazy('clients:start_page')
    cancel_url = success_url
    skip_signup_test = True

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def get_object(self, queryset=None):
        # pylint: disable=no-member
        try:
            return self.model.objects.get(user=self.request.user)
        except self.model.DoesNotExist:
            return None


class BankAccountUpdateView(CompleteSignUpMixin,
                            core.BankAccountCreateAndUpdateBaseView):
    """
    Client banck account
    """

    template_name = 'common/form.html'
    success_url = reverse_lazy('clients:start_page')
    cancel_url = success_url
    skip_signup_test = True


class ProductsView(CompleteSignUpMixin,
                   mixins.TitleMixin,
                   TemplateView):
    """
    Client products view
    """
    title = 'Produtos'
    template_name = 'clients/products/products.html'

    def _get_products(self):
        # pylint: disable=no-member

        user = self.request.user
        investorprofile = getattr(user, 'investorprofile', None)
        products = products_models.Product.objects.none()

        if investorprofile:
            if user.client.is_mr7_client:
                target = [TargetClient.MR7_CLIENT, TargetClient.ALL_CLIENTS]
            else:
                target = [TargetClient.MR7_NOT_CLIENT,
                          TargetClient.ALL_CLIENTS]

            query_target = invest_models.Application.query_target_client_filter(
                target)

            if query_target:
                products = products_models.Product.objects.filter(
                    query_target,
                    application__is_active=True,
                    agreementtemplate__isnull=False,
                    pk__in=list(investorprofile.profile.profileproduct_set.values_list(
                        'product__pk', flat=True)),
                ).annotate(
                    agreement_id=Max('agreementtemplate__pk')
                )

        return products

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        products = self._get_products()
        context['products'] = products
        if self.request.method == 'GET':
            context['purchase_form'] = products_forms.PurchaseForm(
                products=products, user=self.request.user)
        else:
            context['purchase_form'] = products_forms.PurchaseForm(
                self.request.POST, products=products, user=self.request.user)
        context['product_template'] = core_dashboard.ProductsDashboard.template_name
        return context

    # pylint: disable=unused-argument
    def post(self, request, *args, **kwargs):
        """
        Request remote product creation and create a local respective product
        """
        context = self.get_context_data(**kwargs)

        if context['products']:
            form = context['purchase_form']
            if form.is_valid():
                form.save()
                message_modal_add(request, context, 'Parabéns!',
                                  'Investimento contratado com sucesso!')
                return redirect(reverse('clients:start_page'))
        else:
            form.add_error(
                None, 'Contratação indisponível no momento')

        return self.render_to_response(context)


class BrokerView(CompleteSignUpMixin,
                 mixins.TitleMixin,
                 TemplateView):
    """
        Client broker view
    """
    title = "Broker"
    header_message = ''

    template_name = 'clients/broker/broker.html'


class OperationsStatentView(
        CompleteSignUpMixin,
        products_forms_mixins.OperationsFilterMixin,
        mixins.TitleMixin,
        SingleTableMixin,
        TemplateView):
    """
        Client report  view
    """
    title = 'Extrato de movimentação'
    header_message = ''
    template_name = 'clients/reports/operations_statement.html'
    table_class = tables.ReportTable


class ReportView(
        CompleteSignUpMixin,
        mixins.TitleMixin,
        TemplateView):
    """
        Client report  view
    """
    title = 'Relatório'
    header_message = ''
    template_name = 'clients/reports/report.html'


class ProductPurcahseListView(CompleteSignUpMixin,
                              mixins.ListViewMixin):
    """
    Agreements list
    """
    model = products_models.ProductPurchase
    table_class = tables.ProductPurchaseTable
    template_name = 'common/list.html'
    title = 'Investimentos'

    def get_queryset(self):
        queryset = super().get_queryset()
        return queryset.filter(user=self.request.user)


class ProductPurchaseUpdateView(CompleteSignUpMixin,
                                generic.UpdateView):
    """
    Update product
    """

    model = products_models.ProductPurchase
    fields = "__all__"
    template_name = 'common/form.html'
    fields = ['alias', 'auto_renew', 'notify_before_end']
    title = 'Investimento'
    success_url = reverse_lazy('clients:products_purchase_list')
    cancel_url = success_url

    def get_object(self, queryset=None):
        # pylint: disable=no-member
        pp_pk = self.kwargs.get('pk')
        try:
            return self.model.objects.get(pk=pp_pk, user=self.request.user)
        except self.model.DoesNotExist as exc:
            raise Http404(exc) from exc

    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        if days := getattr(config, 'AGREEMENT_NOTIFY_END_BEFORE_DAYS', 15):
            form.fields[
                'notify_before_end'].label = f"Notificar término do contrato {days} antes do vencimento"
        return form


class UserAcceptanceTermListView(CompleteSignUpMixin,
                                 mixins.ListViewMixin):
    """
    Acceptance terms list
    """
    permission_required = 'is_admin'
    model = core_models.AcceptanceTerm
    table_class = tables.AcceptanceTable
    template_name = 'common/list.html'
    title = 'Termos de aceite'

    def get_queryset(self):
        # pylint: disable=no-member
        last_vertions = core_models.AcceptanceTerm.objects.filter(
            is_active=True, type=OuterRef('type')).order_by('-version')
        # pylint: disable=no-member
        last_vertions = core_models.AcceptanceTerm.objects.filter(
            pk=Subquery(last_vertions.values('pk')[:1]))
        return last_vertions


class UserAcceptanceTermPrintView(CompleteSignUpMixin,
                                  generic.PrintView):
    """
    Detail and print view for acceptance terms
    """

    model = core_models.AcceptanceTerm
    template_name = 'common/print.html'
    title = 'Termo de aceite'

    def get_content(self):
        accept_term_pk = self.kwargs.get('pk', None)
        if accept_term_pk:
            try:
                # pylint: disable=no-member
                term = core_models.AcceptanceTerm.objects.get(
                    pk=accept_term_pk,
                )
                return {
                    'title': term.title,
                    'text': term.text
                }
            # pylint: disable=no-member
            except core_models.AcceptanceTerm.DoesNotExist as exc:
                raise Http404(exc) from exc

        return dict()


class UserAcceptanceTermCreateView(ClientRoleMixin,
                                   mixins.PageMenuMixin,
                                   generic.FormView):
    """
    View to accept terms
    """

    menu_template_name = 'clients/menu.html'
    template_name = 'common/term_form.html'
    form_class = forms.UserAcceptanceTermForm
    title = 'Termo de aceite'
    header_message = ''
    success_url = reverse_lazy('clients:start_page')

    def __init__(self) -> None:
        super().__init__()
        # pylint: disable=no-member
        self.term = core_models.AcceptanceTerm.objects.filter(
            type=core_models.AcceptanceTerm.Type.PRIVACY_POLICY, is_active=True).order_by('-version').last()

    def form_valid(self, form):
        form.save()
        return super().form_valid(form)

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        kwargs['term'] = self.term
        return kwargs

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.term:
            context['term'] = {
                'title': self.term.title,
                'text': self.term.text
            }
        return context

    def get_controls(self):
        """
        No controls required
        """
        return [mixins.Control('button', 'button', 'accept', 'Aceitar', 'success')]


class InvestorProfileTestCreateView(ClientRoleMixin,
                                    invprof_view.ProfileTestViewMixin,
                                    mixins.PageMenuMixin,
                                    generic.FormView):
    """
    Investor profile test view
    """
    menu_template_name = 'clients/menu.html'
    template_name = 'clients/accept_form.html'
    title = 'Perfil de investidor'
    header_message = ''
    success_url = reverse_lazy('clients:start_page')


class UserAgreementPrintView(CompleteSignUpMixin,
                             generic.PrintView):
    """
    Detail and print view for acceptance terms
    """

    model = products_models.ProductPurchase
    template_name = 'common/print.html'
    title = 'Contrato'

    def get_content(self):
        product_pk = self.kwargs.get('pk', None)
        if product_pk:
            try:
                # pylint: disable=no-member
                user_agreement = self.model.objects.get(
                    pk=product_pk,
                    user=self.request.user
                )
                return {
                    'text': user_agreement.agreement
                }
                # pylint: disable=no-member
            except self.model.DoesNotExist as exc:
                raise Http404(exc) from exc

        return dict()


class SignupView(accounts_views.SignupView):
    """
    Signup view adpted to client

    If the role set in invitation is CLIENT, presents a modal for
    signup terms acceptance.
    If acceptance_required is true, a term must be given
    """

    def get_term(self):
        # pylint: disable=no-member
        email = self.request.session.get("account_verified_email", None)
        invitation = accounts_roles.has_active_invitation(email)
        if invitation:
            role = accounts_roles.get_role_from_invitation_email(email)
            if role == accounts_roles.Roles.CLIENT:
                self.acceptance_required = True
                term = core_models.AcceptanceTerm.objects.filter(
                    type=core_models.AcceptanceTerm.Type.SIGNUP, is_active=True).order_by('-version').last()
                if term:
                    return {
                        'title': term.title,
                        'text': term.text
                    }
            else:
                self.acceptance_required = False
        else:
            self.acceptance_required = True
            term = core_models.AcceptanceTerm.objects.filter(
                type=core_models.AcceptanceTerm.Type.SIGNUP, is_active=True).order_by('-version').last()
            if term:
                return {
                    'title': term.title,
                    'text': term.text
                }
        return None


class ClientDocsView(auth_mixins.LoginRequiredMixin, generic.FileBaseView):
    """
    View to download client uploaded documents
    Client can view/download only its documents
    Users with ADMIN role has access to all documents
    """

    model = models.Client
    field = 'rg_cnh'
    media_file_root = 'private/'

    def can_access_file(self, request):
        user = request.user
        roles = [accounts_roles.Roles.ADMIN, accounts_roles.Roles.CLIENT]
        if accounts_roles.has_role_in(user, roles):
            return True
        return False

    def queryset(self, file_name, request):

        field_prefix = file_name.split('/')[-1].split('_')[0]

        if field_prefix == 'rc':
            self.field = 'rg_cnh'
        elif field_prefix == 'ap':
            self.field = 'address_proof'
        elif field_prefix == 'ca':
            self.field = 'company_agreement'
        else:
            # pylint: disable=no-member
            return self.model.objects.none()

        data = {
            f'{self.field}__exact': f'{self.media_file_root}{file_name}',
        }

        # pylint: disable=no-member
        query = self.model.objects.filter(**data)

        user = request.user

        if accounts_roles.has_role(user, accounts_roles.Roles.ADMIN):
            return query
        elif accounts_roles.has_role(user, accounts_roles.Roles.CLIENT):
            return query.filter(user=user)
        return query.none()


class ApplicationOpUserListView(CompleteSignUpMixin,
                                products_forms_mixins.OperationsFilterMixin,
                                invest_views.ApplicationOpUserListBaseView):
    """
    Client application operation list view
    """

    def get_queryset(self):
        return super().get_queryset().filter(application_account__user=self.request.user)
