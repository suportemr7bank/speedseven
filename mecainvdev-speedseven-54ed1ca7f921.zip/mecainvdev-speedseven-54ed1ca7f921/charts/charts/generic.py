"""
Generic elements which not belong to any lib or not is a plot

"""

from dataclasses import dataclass

from charts.charts.base import AbstractChart, ChartDataType


@dataclass
class Card(AbstractChart):
    """
    Card element. Only title and text (not a plot)
    """

    text: str = ""
    chart_type = ChartDataType.CARD

    def get_json_data(self):
        """
        Json data to javascript chart library
        """

        return f'''
            <div class="shadow-sm bg-body rounded">
                <div class="h5 pt-2 ps-3 text-secondary">{self.title}</div>
                <div class="h4 pt-2 ps-3 pb-3">{self.text}</div>
            </div>
            '''