"""
    Forms to filter list/table rows
"""

from crispy_forms.bootstrap import FormActions, PrependedText
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Column, Layout, Submit
from django import forms

from common.forms import fields

class OperationsFilterForm(forms.Form):
    """
    Form to filter client operations in report
    """

    product = forms.ChoiceField(label='', choices=[('0', 'Aplicação'),
                                                   ('SPF', 'Speed7'), ('RED', 'Reddex'), ('DU7', 'Dupper7')], required=False)
    operation = forms.ChoiceField(label='', choices=[('op', 'Movimentação'),
                                                     ('APT', 'Aporte'), ('RET', "Retirada"), ('REN', 'Rendimento')], required=False)

    init_date = forms.DateField(
        label='',
        required=False,
        widget=fields.DatePickerInput(options={'dateFormat': 'd/m/Y'}),
        )

    final_date = forms.DateField(
        label='',
        required=False,
        widget=fields.DatePickerInput(options={'dateFormat': 'd/m/Y'}),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.helper = FormHelper()
        self.helper.form_method = 'get'
        self.helper.form_class = 'row'
        self.helper.layout = Layout(
            Column('product', css_class='col-12 col-md-auto'),
            Column('operation', css_class='col-12 col-md-auto'),
            Column(PrependedText('init_date', 'Início'),
                   css_class='col-12 col-md-auto'),
            Column(PrependedText('final_date', 'Fim'),
                   css_class='col-12 col-md-auto'),
            Column(FormActions(Submit('', 'Filtrar', css_class='col-12')),
                   css_class='col-12 col-md-auto')
        )
