"""
Admin site
"""

from django.contrib import admin

from .models import ProfileProduct, AgreementTemplate


@admin.register(ProfileProduct)
class ProfileProductAdmin(admin.ModelAdmin):
    """
    Profile admin model
    """


@admin.register(AgreementTemplate)
class AgreementTemplateAdmin(admin.ModelAdmin):
    """
    Agreement template admin model
    """
