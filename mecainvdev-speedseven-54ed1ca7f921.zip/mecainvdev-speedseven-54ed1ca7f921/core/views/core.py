"""
    Core adminitrative view
"""

from django.contrib.auth import forms as auth_forms
from django.http import Http404
from django.urls import reverse, reverse_lazy
from django.views.generic import TemplateView


from investorprofile import models as invprof_models

from clients import models as clients_models
from clients import forms as clients_forms
from common.forms import mixins as forms_mixins
from common.messages import message_add
from common.views import generic, mixins

from core import models as core_models

from products import models as products_models


from .. import tables
from ..forms import core


class StartView(mixins.AdminMixin, TemplateView):
    """
        Admin start view
    """
    template_name = 'core/start.html'

    def get_context_data(self, **kwargs):
        # pylint: disable=no-member

        context = super().get_context_data(**kwargs)

        context['account_term'] = core_models.AcceptanceTerm.objects.filter(
            type=core_models.AcceptanceTerm.Type.ACCOUNT).exists()
        context['signup_term'] = core_models.AcceptanceTerm.objects.filter(
            type=core_models.AcceptanceTerm.Type.SIGNUP).exists()

        count_prod = products_models.Product.objects.all().count()
        context['products_num'] = count_prod
        context['agreements_num'] = count_prod - \
            products_models.Product.objects.filter(
                agreementtemplate__isnull=True).count()

        context['invprof_num'] = invprof_models.Profile.objects.all().count()

        context['has_profile_test'] = invprof_models.ProfileTest.objects.filter(
            is_active=True).exists()

        context['dashboards_num'] = count_prod - \
            products_models.Product.objects.filter(
                productdashboard__isnull=True).count()

        return context


class AdminListView(mixins.AdminMixin,
                    forms_mixins.UserNameEmailFilterMixin,
                    mixins.ListViewMixin):
    """
        Admin list
    """
    model = core_models.User
    table_class = tables.AdminTable
    template_name = 'common/list.html'
    title = 'Administradores'

    def get_queryset(self):
        return super().get_queryset().filter(is_superuser=True)


class ChangeUserPasswordView(mixins.AdminMixin,
                             generic.FormView):
    """
    Change user password
    """
    form_class = auth_forms.SetPasswordForm
    success_url = reverse_lazy('core:user_list')
    template_name = 'common/form.html'
    title = "Alterar senha"
    cancel_url = success_url

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        user_id = self.kwargs['pk']
        try:
            user = core_models.User.objects.get(pk=user_id)
            kwargs['user'] = user

            self.header_message = user.email
        # pylint: disable=no-member
        except core_models.User.DoesNotExist as ex:
            kwargs['user'] = None
            # TODO: redirecionar para página de erro
            raise ex
        return kwargs

    def form_valid(self, form):
        # From is not automatically saved
        form.save()
        message_add(self.request, 'Senha alterada com sucesso!')
        return super().form_valid(form)


class ChangeAdminPasswordView(ChangeUserPasswordView):
    """
    Change asmin password
    """
    success_url = reverse_lazy('core:admin_list')
    cancel_url = success_url
    form_class = auth_forms.PasswordChangeForm

    def _check_user(self, request, kwargs):
        """
        Asserts only logged user can change his/her password
        """
        try:
            user_id = kwargs['pk']
            user = core_models.User.objects.get(pk=user_id)
            if user != request.user:
                #TODO: customize
                return False
        # pylint: disable=no-member
        except core_models.User.DoesNotExist:
            return False

        return True

    def get(self, request, *args, **kwargs):
        if not self._check_user(request, kwargs):
            raise Http404
        return super().get(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        if not self._check_user(request, kwargs):
            raise Http404
        return super().post(request, *args, **kwargs)

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        user_id = self.kwargs['pk']
        try:
            user = core_models.User.objects.get(pk=user_id)
            kwargs['user'] = user

            message = (
                '<span class="text-danger">Atençao!</span>'
                ' Será feito logout automático após mudança de senha'
            )

            self.header_message = f'<p>{user.email}</p> {message}'
        #pylint: disable=no-member
        except core_models.User.DoesNotExist as ex:
            kwargs['user'] = None
            # TODO: redirecionar para página de erro
            raise ex
        return kwargs


class ChangePasswordMixin:
    """
    Insert a button to change password
    """

    def get_password_url(self):
        """
        Url for changing password
        """
        return ''

    def get_controls(self):
        """
        Insert a button to change password
        """
        controls = super().get_controls()
        url = self.get_password_url()
        if url:
            controls.insert(
                1,
                mixins.ControlFactory.link_button(
                    'Alterar senha', url, 'secondary'),
            )

        return controls


class AdminUpdateView(mixins.AdminMixin,
                      ChangePasswordMixin,
                      generic.UpdateView):
    """
        Create admin
    """
    model = core_models.User
    form_class = core.UserForm
    template_name = 'common/form.html'
    title = 'Administradores'
    success_url = reverse_lazy('core:admin_list')
    cancel_url = success_url

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def get_password_url(self):
        if self.object.pk == self.request.user.pk:
            return reverse('core:change_admin_password', kwargs={'pk': self.object.pk})
        return None


class UserListView(mixins.AdminMixin,
                   forms_mixins.UserNameEmailFilterMixin,
                   mixins.ListViewMixin):
    """
        Admin list
    """
    model = core_models.User
    table_class = tables.UserTable
    template_name = 'common/list.html'
    title = 'Ativação e senha'

    def get_queryset(self):
        return super().get_queryset().filter(is_superuser=False).order_by('-id')


class UserUpdateView(mixins.AdminMixin,
                     ChangePasswordMixin,
                     generic.UpdateView):
    """
        Update user
    """
    model = core_models.User
    form_class = core.UserForm
    template_name = 'common/form.html'
    title = 'Ativação e senha'
    success_url = reverse_lazy('core:user_list')
    cancel_url = success_url

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def get_password_url(self):
        return reverse('core:change_user_password', kwargs={'pk': self.object.pk})


class ClientListView(mixins.AdminMixin,
                      forms_mixins.UserNameEmailFilterMixin,
                      mixins.ListViewMixin):
    """
        Admin list
    """
    model = clients_models.Client
    table_class = tables.ClientsTable
    template_name = 'common/list.html'
    title = 'Clientes'
    controls = [
        {'link': {'text': 'Novo', 'url': 'core:client_create'}},
    ]


class ClientCreateView(mixins.AdminMixin,
                       generic.CreateView):
    """
        Update client
        Client is creates by signal when user signed up
    """
    model = clients_models.Client
    form_class = clients_forms.ClientForm
    template_name = 'common/form.html'
    title = 'Dados pessoais'
    success_url = reverse_lazy('core:client_list')
    cancel_url = success_url
    skip_signup_test = True


class ClientUpdateView(mixins.AdminMixin,
                       generic.UpdateView):
    """
        Update client
        Client is creates by signal when user signed up
    """
    model = clients_models.Client
    form_class = clients_forms.ClientForm
    template_name = 'common/form.html'
    title = 'Dados pessoais'
    success_url = reverse_lazy('core:client_list')
    cancel_url = success_url
    skip_signup_test = True

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.object.user
        return kwargs

