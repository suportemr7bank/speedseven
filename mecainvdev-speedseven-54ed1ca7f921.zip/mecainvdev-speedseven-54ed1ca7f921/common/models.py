"""
User model
"""
from django.conf import settings
from django.db import models

class Bank(models.Model):
    """
    Bank model
    """
    class Meta:
        """
        Meta class
        """
        verbose_name = 'Banco'

    code = models.IntegerField(verbose_name='Código', null=True, blank=True)
    name = models.CharField(verbose_name='Nome', max_length=255)
    ispb = models.IntegerField(verbose_name='ISPB', null=True, blank=True)

    def __str__(self):
        return f'{self.code} - {self.name}'


class BankAccount(models.Model):
    """
    Bank account
    """

    class Meta:
        """
        Meta class
        """
        verbose_name = 'Conta bancária'
        verbose_name_plural = 'Contas bancárias'

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    bank = models.ForeignKey(Bank, verbose_name='Banco',
                             on_delete=models.CASCADE, null=True, blank=True)
    bank_branch_number = models.IntegerField(
        verbose_name='Agência', null=True, blank=True)
    bank_branch_digit = models.CharField(
        verbose_name='Dígito da agência', max_length=1, null=True, blank=True)
    account_number = models.IntegerField(
        verbose_name='Número da conta', null=True, blank=True)
    account_digit = models.IntegerField(
        verbose_name='Dígito da conta', null=True, blank=True)

    @property
    def branch(self):
        """
        Bank branch
        """
        if self.bank_branch_digit:
            return f'{self.bank_branch_number}-{self.bank_branch_digit}'
        else:
            return self.bank_branch_number

    @property
    def account(self):
        """
        User bank account
        """
        if self.account_digit:
            return f'{self.account_number}-{self.account_digit}'
        else:
            return self.account_number

    @property
    def registration_completed(self):
        """
        Indicate if registration is completed
        """
        #pylint: disable=no-member
        return self.bank and self.bank_branch_number and self.account_number

    def __str__(self):
        #pylint: disable=no-member
        return f'{self.user.get_full_name()} - {self.bank}'
