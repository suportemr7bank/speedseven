"""
Accounts models
"""

import datetime
from django.conf import settings
from django.db import models
from django.utils import timezone

from invitations.models import Invitation as _Invitation
from invitations.app_settings import app_settings

try:
    from constance import config

    def _get_invitation_expiry():
        return getattr(config, 'ACCOUNT_INVITATION_EXPIRY', app_settings.INVITATION_EXPIRY)
except ImportError:
    def _get_invitation_expiry():
        return app_settings.INVITATION_EXPIRY


class Roles(models.TextChoices):
    """
    Platoform role
    """
    ADMIN = 'ADMIN', 'Administrador'
    CLIENT = 'CLIENT', 'Cliente'
    BROKER = 'BROKER', 'Gerente de conta'
    UNDEF = 'UNDEF', 'Indefinido'


class RoleModelMixin(models.Model):
    """
    Mixin form role
    """
    class Meta:
        """
        Meta class
        """
        abstract = True

    role = models.CharField(max_length=6, choices=Roles.choices)


class Invitation(RoleModelMixin, _Invitation):
    """
    Invitation model customization
    """

    expiration_date = models.DateTimeField(
        verbose_name=('Vencimento'), null=True, blank=True)

    error_message = models.TextField(verbose_name='Mensagem de erro', null=True, blank=True)

    def key_expired(self):
        if self.expiration_date:
            return self.expiration_date < timezone.now()
        else:
            return False

    def send_invitation(self, request, **kwargs):
        try:
            super().send_invitation(request, **kwargs)
            self.expiration_date = (self.sent + datetime.timedelta(days=_get_invitation_expiry()))
        except Exception as err:
            self.error_message = str(err)
        self.save()


class UserRole(RoleModelMixin):
    """
    User role
    """
    class Meta:
        """
        Meta class
        """
        verbose_name = 'Papel do usuário'
        verbose_name_plural = 'Papéis dos usuários'
        constraints = [
            models.UniqueConstraint(fields=['user', 'role'], name='unique_user_role_constraint')
        ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)


    def __str__(self) -> str:
        return f'{self.user.email} - {self.role}'
