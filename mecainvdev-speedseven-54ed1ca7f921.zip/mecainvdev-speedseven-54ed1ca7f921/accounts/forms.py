"""
Forms customization
"""

from allauth.account.forms import LoginForm as _LoginForm
from allauth.account.forms import SignupForm as _SignupForm
from django import forms

from accounts import roles as account_roles

from .invitations import Invitation


class SignupForm(_SignupForm):
    """
    Remove username from form
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._init_default()

    def _init_default(self):
        self.fields.pop('username')
        self.fields['email'].label = ''
        self.fields['email'].widget.attrs.update(
            {'placeholder': "Endereço de email*"})
        self.fields['password1'].label = ''
        self.fields['password2'].label = ''

    def save(self, request):
        user = super().save(request)
        user.username = user.email
        user.save()
        account_roles.create_user_role_from_invitation(user)
        return user


class LoginForm(_LoginForm):
    """
    Remove username from form
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['login'].label = ''
        self.fields['password'].label = ''


class InvitationForm(forms.ModelForm):
    """
    Invitation form customization. Only to get data. Do not handle saving.
    -Send email in background
    -Only admin as inviter
    """

    class Meta:
        """
        Meta class
        """
        model = Invitation
        fields = ['email', 'role']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Removing undefined (UNDEF) role
        choices = list(account_roles.Roles.choices)
        choices.pop()
        self.fields['role'].choices = choices

    def clean(self):
        cleaned_data = super().clean()
        # instace existis only for update
        if not self.instance:
            if Invitation.objects.filter(email=cleaned_data['email']).exists():
                self.add_error('email', 'Já exite um convite para este email')
        return cleaned_data
