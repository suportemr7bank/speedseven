"""
Client signals
"""

from django.dispatch import receiver
from allauth.account.signals import user_signed_up

from accounts import roles as accounts_roles
from core import models as core_models

from .models import Client


@receiver(user_signed_up)
#pylint: disable=unused-argument
def create_client(sender, **kwargs):
    """
    Create a client after signup
    """
    user = kwargs['user']
    if accounts_roles.has_role(user, accounts_roles.Roles.CLIENT):
        account_type = kwargs['form_data']['account_type']
        cpf = kwargs['form_data']['cpf']
        data = {
            'user': user,
            'type': account_type,
            'cpf': cpf
        }

        # pylint: disable=no-member
        Client.objects.create(**data)

        # pylint: disable=no-member
        core_models.UserAcceptanceTerm.objects.create(
            user=user,
            term=core_models.AcceptanceTerm.objects.filter(
                type=core_models.AcceptanceTerm.Type.SIGNUP, is_active=True).last()
        )
