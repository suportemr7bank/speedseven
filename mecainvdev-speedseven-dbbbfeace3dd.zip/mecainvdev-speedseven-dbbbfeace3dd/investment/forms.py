"""
Investiment forms
"""
from crispy_forms.helper import FormHelper, Layout
from crispy_forms.layout import HTML
from django import forms
from django.db import transaction
from django.utils import timezone
from django.contrib.auth import get_user_model

from accounts import roles

from . import models
from .operations.operations import ApplicationAccountOperation


class OperationBaseForm(forms.ModelForm):
    """
    Base form for operations
    """

    class Meta:
        """
        Meta class
        """
        model = models.ApplicationOp
        fields = ['operation_type', 'value', 'operation_date', 'description']

    def __init__(self, *args, **kwargs):
        self.application_account = kwargs.pop('application_account')
        self.operator = kwargs.pop('user')
        super().__init__(*args, **kwargs)
        self.fields['operation_date'].required = False
        self.app_op = ApplicationAccountOperation()

        last_op = self.application_account.applicationop_set.last()
        if last_op:
            balance = last_op.balance
            operation_date = timezone.localtime(
                last_op.operation_date).strftime('%d/%m/%Y %H:%M:%S')
        else:
            balance = 0
            operation_date = '-----'

        self.set_layout(balance, operation_date)

    def set_layout(self, balance, operation_date):
        """ Set layout """
        self.helper = FormHelper()
        fields = [
            HTML(f'<p>{self.application_account.user.get_full_name()}</p>'),
            HTML(f'<p> Última operação: {operation_date} </p>'),
            HTML(
                f'<p class="pb-4"> <strong>Saldo da aplicação:</strong> R${balance}</p>'),
        ]
        fields = fields + [key for key, value in self.fields.items()]
        self.helper.layout = Layout(*fields)

    def _get_operation_date(self, cleaned_data):
        operation_date = cleaned_data.get('operation_date')
        if not operation_date:
            operation_date = timezone.localtime(timezone.now())
        return operation_date

    def save(self, commit=False):
        operation_date = self._get_operation_date(self.cleaned_data)

        # pylint: disable=assignment-from-none
        obj = self.make_operation(operation_date)
        return obj

    # pylint: disable=unused-argument
    def make_operation(self, operation_date):
        """
        Make application operation
        """
        return None


class DepositiForm(OperationBaseForm):
    """
    Deposit form
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['operation_type'].choices = models.ApplicationOp.OperationType.deposit_choices

    def clean(self):
        cleaned_data = super().clean()
        opeartion_date = self._get_operation_date(cleaned_data)
        self.app_op.validate_deposit(
            application_account=self.application_account,
            value=self.cleaned_data['value'], operation_date=opeartion_date)
        return cleaned_data

    def make_operation(self, operation_date):
        return self.app_op.make_deposit(
            operator=self.operator,
            application_account=self.application_account,
            value=self.cleaned_data['value'],
            description=self.cleaned_data['description'],
            operation_date=operation_date)


class WithdrawForm(OperationBaseForm):
    """
    Withdraw form
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['operation_type'].choices = models.ApplicationOp.OperationType.withdraw_choices

    def clean(self):
        cleaned_data = super().clean()
        opeartion_date = self._get_operation_date(cleaned_data)
        self.app_op.validate_withdraw(
            application_account=self.application_account,
            value=self.cleaned_data['value'], operation_date=opeartion_date)
        return cleaned_data

    def make_operation(self, operation_date):
        operation_type = self.cleaned_data['operation_type']
        return self.app_op.make_withdraw(
            operator=self.operator,
            application_account=self.application_account,
            value=self.cleaned_data['value'],
            operation_type=operation_type,
            description=self.cleaned_data['description'],
            operation_date=operation_date)


class CloseApplicationForm(OperationBaseForm):
    """
    Close application form
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields.pop('value')

    def make_operation(self, operation_date):
        return self.app_op.close_application(
            operator=self.operator,
            application_account=self.application_account,
            description=self.cleaned_data['description'],
            operation_date=operation_date
        )

    def set_layout(self, balance, operation_date):
        """ Set layout """
        self.helper = FormHelper()
        self.helper.layout = Layout(
            HTML(
                '<div class="alert-warning p-2">'
                '   <p class="m-1 p-0"> Atenção!!! Esta operação não pode ser desfeita</p>'
                '   <p class="m-1 p-0">O saldo em conta será zerado e a aplicação desativada</p>'
                '</div>'
            ),
            HTML(
                f'<p class="pt-4">{self.application_account.user.get_full_name()}</p>'),
            HTML(f'<p> Última operação: {operation_date} </p>'),
            HTML(
                f'<p class="pb-4"> <strong>Saldo da aplicação:</strong> R${balance}</p>'),
            'operation_date',
            'description'
        )


class ApplicationAccountForm(forms.ModelForm):
    """
    Base form for operations
    """

    class Meta:
        """
        Meta class
        """
        model = models.ApplicationAccount
        fields = ['user', 'application']

    def __init__(self, *args, **kwargs):
        self.operator = kwargs.pop('user')
        super().__init__(*args, **kwargs)
        user_model = get_user_model()
        self.fields['user'].choices = user_model.objects.filter(
            is_active=True, userrole__role=roles.Roles.CLIENT).values_list('pk', 'email')

    def save(self, commit=True):
        obj = super().save(commit=False)
        obj.operator = self.operator
        if commit:
            with transaction.atomic():
                created = self.instance.pk is not None
                obj.save()
                if not created:
                    obj.post_create()
        return obj


class ApplicationForm(forms.ModelForm):
    """
    Base form for operations
    """

    class Meta:
        """
        Meta class
        """
        model = models.Application
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        self.operator = kwargs.pop('user')
        super().__init__(*args, **kwargs)
        if self.instance.pk:
            self.fields['application_model'].disabled = True

    def save(self, commit=True):
        obj = super().save(commit=False)
        obj.operator = self.operator
        if commit:
            with transaction.atomic():
                created = self.instance.pk is not None
                obj.save()
                if not created:
                    app_class = obj.application_class
                    app_class.aplication_post_create(obj)
                    obj.date_activated = timezone.localtime(timezone.now())
                obj.save()
        return obj


class ApplicationModelForm(forms.ModelForm):
    """
    Base form for operations
    """

    class Meta:
        """
        Meta class
        """
        model = models.ApplicationModel
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        self.operator = kwargs.pop('user')
        super().__init__(*args, **kwargs)
        if self.instance.pk:
            self.fields['app_model_class'].disabled = True

    def save(self, commit=True):
        obj = super().save(commit=False)
        obj.operator = self.operator
        if commit:
            obj.save()
        return obj
