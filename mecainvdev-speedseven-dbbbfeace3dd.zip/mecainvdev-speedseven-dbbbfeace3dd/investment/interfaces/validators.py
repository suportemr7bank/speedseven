"""
Generic validators
"""


from django.core.exceptions import ValidationError

def validate_greate_than_zero(value):
    """
    Values must be greater than zero
    """
    if value <= 0:
        raise ValidationError("Valor deve ser maior ou igual a zero")


def validate_null_or_greate_than_zero(value):
    """
    Values must be greater than zero or None
    """
    if value is not None and value <= 0:
        raise ValidationError("Valor deve ser maior ou igual a zero")