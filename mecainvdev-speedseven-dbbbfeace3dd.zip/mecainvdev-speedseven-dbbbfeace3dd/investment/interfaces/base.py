"""
Application model interfaces

"""

from enum import Enum
from django.db import models


class TargetClient(models.TextChoices):
    """
    Define client target available
    """
    MR7_CLIENT = 'MR7C', 'Clientes com conta mr7'
    MR7_NOT_CLIENT = 'MR7N', 'Clientes sem conta mr7'
    ALL_CLIENTS = 'ALLC', 'Todos os clientes'


class ApplicationSettingBaseModel(models.Model):
    """
    Base model for application settings
    The target_client is used to selec which client can see the products
    """

    class Meta:
        """
        Meta class
        """
        abstract = True

    target_client = models.CharField(
        verbose_name='Cliente alvo', max_length=4,
        help_text='Define para quais clientes esta applicação estará disponível',
        choices=TargetClient.choices, default=TargetClient.MR7_CLIENT)


class ApplicationFormType(Enum):
    """
    Application forms
    """
    APPLICATION_SETTINGS = 1
    ACCOUNT_SETTINGS = 2
    DEPOSIT = 3
    WITHDRAW = 4
    OPERATION_APPROVAL = 5


class PostCreateState(Enum):
    """
    State after creaation
    Created means the application was created
    Scheduled means the creation process depends on externa factor and
    may be executed in a backgroud task. (Ex: creating an account in a broker)
    In the scheduled case, the implementation should finalize application creation
    settint its date_activated
    """
    CREATED = 1
    SCHEDULED = 2
    RUNNING = 3


class ApplicationModelClassBase:
    """
    Base class to create application models
    """
    settings_related_name = None
    application_settings_form = None
    account_settings_form = None
    deposit_form = None
    withdraw_form = None
    operation_approval_form = None

    @classmethod
    def get_form(cls, form: ApplicationFormType):
        """
        Application specific forms
        """
        if form == ApplicationFormType.APPLICATION_SETTINGS:
            return cls.application_settings_form
        elif form == ApplicationFormType.ACCOUNT_SETTINGS:
            return cls.account_settings_form
        elif form == ApplicationFormType.DEPOSIT:
            return cls.deposit_form
        elif form == ApplicationFormType.WITHDRAW:
            return cls.withdraw_form
        elif form == ApplicationFormType.OPERATION_APPROVAL:
            return cls.operation_approval_form

        return None

    @classmethod
    def aplication_post_create(cls, application):
        """
        Method called after application was created
        This method is called inside a transaction and should not hang
        """
        application.settings_related_name = cls.settings_related_name
        application.save()

    @classmethod
    def aplication_account_post_create(cls, application_account) -> PostCreateState:
        """
        Method called after application account was created
        This method is called inside a transaction and should not hang
        """
