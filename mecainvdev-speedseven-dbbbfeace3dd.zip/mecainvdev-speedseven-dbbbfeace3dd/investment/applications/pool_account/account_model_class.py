"""
Application definitions
"""

from investment.interfaces.base import ApplicationModelClassBase, PostCreateState

from . import forms, models

class SimpleInterestPoolAccount(ApplicationModelClassBase):
    """
    Class with application definitons
    """
    settings_related_name = 'pool_account_settings'
    application_settings_form = forms.ApplicationSettingsForm
    account_settings_form = forms.AccountSettingsForm
    deposit_form = forms.ManualDepositForm
    withdraw_form = forms.ManualWithdrawForm
    operation_approval_form = forms.OperationApprovalForm


    @classmethod
    def aplication_post_create(cls, application):
        super().aplication_post_create(application)
        # pylint: disable=no-member
        models.ApplicationSettings.objects.create(
            application=application,
            min_initial_deposit=10000,
            min_deposit=1000,
            deposit_term=7,
            ranges='0,00; 100000,00; 500000,00',
            withdraw_account_term=15,
            withdraw_income_term=10,
            value_threshold=1000000,
            withdraw_threshold_term=20
        )

    @classmethod
    def aplication_account_post_create(cls, application_account) -> PostCreateState:
        # pylint: disable=no-member
        models.AccountSettings.objects.create(
            application_account=application_account
        )
        return PostCreateState.CREATED
