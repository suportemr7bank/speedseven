"""
Application models
"""


from django.db import models
from investment.interfaces.base import ApplicationSettingBaseModel
from investment.models import Application


class ApplicationSettings(ApplicationSettingBaseModel):
    """
    Application model settings
    """

    class Meta:
        """
        Meta class
        """
        verbose_name = 'Configuração da aplicação'
        verbose_name_plural = 'Configurações das aplicações'

    application = models.OneToOneField(
        Application, verbose_name='Aplicação', related_name='ninja_trader_settings',
        on_delete=models.CASCADE, editable=False)
