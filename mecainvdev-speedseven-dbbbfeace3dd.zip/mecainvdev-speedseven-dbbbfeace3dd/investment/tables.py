"""
Investment tables
"""

from itertools import product
import django_tables2 as tables
from django.utils.safestring import mark_safe
from . import models


class ApplicationAccountTable(tables.Table):
    """
    Application table
    """

    operations = tables.TemplateColumn(
        verbose_name='',
        template_name='investment/application_menu.html',
    )

    name = tables.Column(
        verbose_name='Cliente',
        accessor='user__get_full_name',
        order_by=('user__first_name', 'user__last_name')
    )

    user__email = tables.Column(verbose_name='Email')

    config = tables.TemplateColumn(
        verbose_name='',
        template_code="{% if record.application.has_account_settings %}"
                      "<a href='{% url \"investment:applicationaccount_settings\" record.id  %}'>"
                      "<i class='bi bi-gear'></i> </a>"
                      "{% else %}"
                      " <i class='bi bi-gear text-muted'></i> "
                      "{% endif %}"
    )

    class Meta:
        """ Meta class"""
        model = models.ApplicationAccount
        attrs = {"class": "table table-striped table-hover"}
        template_name = "django_tables2/bootstrap-responsive.html"
        fields = ('id', 'operations', 'config', 'application', 'name', 'user__email', 'operator',
                  'date_created', 'date_activated', 'date_deactivated', 'is_active')


class ApplicationOpTable(tables.Table):
    """
    Application operation table
    """

    application_account = tables.Column(
        verbose_name='Conta',
        accessor='application_account',
    )

    class Meta:
        """ Meta class"""
        model = models.ApplicationOp
        attrs = {"class": "table table-striped table-hover"}
        template_name = "django_tables2/bootstrap-responsive.html"
        fields = ('id', 'application_account', 'application_account__application', 'operation_type',
                  'description', 'operation_date', 'value', 'balance')
        order_by = ('-operation_date')


class ApplicationModelTable(tables.Table):
    """
    Application model table
    """

    edit = tables.TemplateColumn(
        verbose_name='',
        template_code="<a href='{% url \"investment:applicationmodel_update\" record.id  %}'> <i class='bi bi-pencil-square'></i> </a>")

    class Meta:
        """ Meta class"""
        model = models.ApplicationModel
        attrs = {"class": "table table-striped table-hover"}
        template_name = "django_tables2/bootstrap-responsive.html"
        fields = ('id', 'edit', 'display_text',
                  'app_model_class', 'operator', 'date_created', 'is_active')


class ApplicationTable(tables.Table):
    """
    Application table
    """

    edit = tables.TemplateColumn(
        verbose_name='',
        template_code="<a href='{% url \"investment:application_update\" record.id  %}'>"
                      "<i class='bi bi-pencil-square'></i> </a>")

    config = tables.TemplateColumn(
        verbose_name='',
        template_code="{% if record.has_application_settings %}"
                      "<a href='{% url \"investment:application_settings\" record.id  %}'> <i class='bi bi-gear'></i> </a>"
                      "{% else %}"
                      " <i class='bi bi-gear text-muted'></i> "
                      "{% endif %}"
    )

    product = tables.Column(
        verbose_name='Produto'
    )

    target_client = tables.Column(
        verbose_name='Cliente alvo',
        accessor='target_client_display'
    )

    class Meta:
        """ Meta class"""
        model = models.Application
        attrs = {"class": "table table-striped table-hover"}
        template_name = "django_tables2/bootstrap-responsive.html"
        fields = ('id', 'edit', 'config', 'display_text', 'product', 'application_model', 'target_client', 'operator',
                  'date_created', 'date_activated', 'is_active')


class MoneyTransferBaseTable(tables.Table):
    """
    Application base model table
    """

    state = tables.Column(
        verbose_name='Situação'
    )

    product = tables.Column(verbose_name='Produto', empty_values=())

    class Meta:
        """ Meta class"""
        model = models.MoneyTransfer
        attrs = {"class": "table table-striped table-hover"}
        template_name = "django_tables2/bootstrap-responsive.html"
        fields = ('product', 'operation', 'state',
                  'date_created', 'date_finished', 'value')
        order_by = ('-id')

    def render_product(self, value, record):
        """
        Try return the product name otherwise return applcation name
        """
        if getattr(record.application_account.application, 'product', None):
            return record.application_account.application.product.display_text
        else:
            return record.application_account.display_name


class MoneyTransferTable(MoneyTransferBaseTable):
    """
    Application model table
    """

    state = tables.TemplateColumn(
        verbose_name=mark_safe('<i class="bi bi-arrow-down-up"></i>'),
        template_code="{% if record.state == \"WAIT\" %}"
                      "<i class='bi bi-clock' title='Aguardando'></i>"
                      "{% elif record.state == \"RUNN\" %}"
                      " <i class='bi bi-play-circle text-primary' title='Em execuçao'></i> "
                      "{% elif record.state == \"FINI\" %}"
                      " <i class='bi bi-check-circle text-success' title='Finalizado'></i> "
                      "{% elif record.state == \"ERRO\" %}"
                      " <i class='bi bi-x-circle text-danger' title='{{record.error_message|default_if_none:'-----'}}'></i> "
                      "{% endif %}"
    )

    edit = tables.TemplateColumn(
        verbose_name='',
        template_code="{% if record.processing == \"MANU\" %}"
                      "<a href='{% url \"investment:moneytransfer_approval\" record.id  %}'>"
                      "<i class='bi bi-pencil-square'></i> </a>"
                      "{% else %}"
                      " <i class='bi bi-pencil-square text-muted'></i> "
                      "{% endif %}"
    )

    processing = tables.TemplateColumn(
        verbose_name=mark_safe('<i class="bi bi-arrow-down-up"></i>'),
        template_code="{% if record.processing == \"MANU\" %}"
                      "<i class='bi bi-person' title='Tarefa manual'></i>"
                      "{% else %}"
                      " <i class='bi bi-hdd-stack' title='Tarefa automática'></i> "
                      "{% endif %}"
    )

    trial = tables.TemplateColumn(
        verbose_name=mark_safe('<i class="bi bi-arrow-down-up"></i>'),
        template_code='<i class="bi bi-arrow-clockwise" title="Tentativa"></i> {{record.trial}}'
    )

    class Meta:
        """ Meta class"""
        model = models.MoneyTransfer
        attrs = {"class": "table table-striped table-hover"}
        template_name = "django_tables2/bootstrap-responsive.html"
        fields = ('id', 'edit', 'processing', 'state', 'trial', 'application_account', 'operation',
                  'date_created', 'date_finished', 'operator', 'processor', 'value')
        order_by = ('-id')


class AccountOpScheduleTable(tables.Table):
    """
    Application account operation table
    """

    operation_date = tables.DateTimeColumn(
        verbose_name='Agendamento',
        format='d/m/Y'
    )

    class Meta:
        """ Meta class"""
        model = models.AccountOpSchedule
        attrs = {"class": "table table-striped table-hover"}
        template_name = "django_tables2/bootstrap-responsive.html"
        fields = (
            'id',
            'money_transfer__application_account',
            'money_transfer__operation',
            'state',
            'money_transfer__date_created',
            'operation_date',
            'operator',
            'money_transfer__processor__user',
            'money_transfer__value'
        )
        order_by = ('-id')
