"""
Application avalilable to create and application model
"""

# pylint: disable=unused-import
from .applications.pool_account.account_model_class import SimpleInterestPoolAccount
from .applications.ninjatrader_account.account_model_class import NinjaTradertPoolAccount
