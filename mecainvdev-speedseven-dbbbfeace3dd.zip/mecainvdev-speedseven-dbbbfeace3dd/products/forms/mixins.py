
"""
Core mixins

"""

from common.forms.mixins import FilterFormMixin

from. import filters


class OperationsFilterMixin(FilterFormMixin):
    """
    Filter client operation in reports
    """

    filter_form_class = filters.OperationsFilterForm

    def apply_filter(self, queryset, filter_form):
        """
            Apply filter to queryset
        """
        return queryset
