"""
Admin site
"""

from django.contrib import admin

from .models import ProfileProduct, AgreementTemplate, ProductPurchase


@admin.register(ProfileProduct)
class ProfileProductAdmin(admin.ModelAdmin):
    """
    Profile product admin model
    """


@admin.register(AgreementTemplate)
class AgreementTemplateAdmin(admin.ModelAdmin):
    """
    Agreement template admin model
    """


@admin.register(ProductPurchase)
class ProductPurchaseAdmin(admin.ModelAdmin):
    """
    Product purchase admin model
    """
