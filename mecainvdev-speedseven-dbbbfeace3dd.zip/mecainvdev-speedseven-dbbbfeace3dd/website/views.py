"""
Webite public views
"""

from django.views.generic import TemplateView

from products.models import Product


class ProducsMixin:
    """
    Add products in the template context
    """

    def get_context_data(self, **kwargs):
        """
        Add products to context
        """
        context = super().get_context_data(**kwargs)
        # pylint: disable=no-member
        context['products'] = Product.objects.filter(
            application__is_active=True)
        return context


class LandingView(ProducsMixin, TemplateView):
    """
    Site landing page
    """
    template_name = 'website/home.html'


class ProductsView(ProducsMixin, TemplateView):
    """
    Site landing page
    """
    template_name = 'website/products.html'
