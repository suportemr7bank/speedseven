"""
    Client views
"""

from accounts.auth import mixins as auth_mixins
from common import models
from common.forms import core as core_forms
from common.views import generic


class BankAccountCreateAndUpdateBaseView(
        auth_mixins.LoginRequiredMixin,
        generic.UpdateView):
    """
        Update client
        Client is creates by signal when user signed up
    """
    model = models.BankAccount
    form_class = core_forms.BanckAccountForm
    title = 'Conta bancária'

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def get_object(self, queryset=None):
        # pylint: disable=no-member
        try:
            return self.model.objects.get(user=self.request.user)
        except self.model.DoesNotExist:
            return None

